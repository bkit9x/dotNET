﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ThongTinHangHoa
{
    public partial class Form1 : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=KIT\SQLEXPRESS;Initial Catalog=QLBH;Integrated Security=True");
        public Form1()
        {
            InitializeComponent();            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //load dgv
            updateDataGridView();

            if (ConnectionState.Closed == conn.State)
                conn.Open();

            //load cbxLoai
            SqlCommand com = new SqlCommand();
            com.Connection = conn;
            com.CommandText = "select MaLoai, TenLoai from LOAIHANG";
            SqlDataReader sdr2 = com.ExecuteReader();

            DataTable dt2 = new DataTable();
            dt2.Load(sdr2);
            cbxLoai.DataSource = dt2;
            cbxLoai.DisplayMember = "TenLoai";
            cbxLoai.ValueMember = "MaLoai";
            sdr2.Close();
            com.Dispose();

            conn.Close();

            dgvHangHoa.Rows[0].Selected = true;
        }

        private void updateDataGridView()
        {
            if (ConnectionState.Closed == conn.State)
                conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            //load datagridview
            cmd.CommandText = "select h.MaHang, h.TenHang, h.DVTinh, h.DonGia, h.SoLuongMua, l.TenLoai from HANGHOA as h, LOAIHANG as l where h.MaLoai = l.MaLoai";
            SqlDataReader sdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(sdr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                dt.Rows[i]["MaHang"] = dt.Rows[i]["MaHang"].ToString().Trim();
            }
            dgvHangHoa.DataSource = dt;
            dgvHangHoa.AutoResizeColumns();
            string[] VietSub = { "Mã hàng", "Tên hàng", "Đơn vị tính", "Giá", "Số lượng", "Tên loại" };
            for (int i = 0; i < VietSub.Length; i++)
            {
                dgvHangHoa.Columns[i].HeaderText = VietSub[i];
            }
            dt.Dispose();
            sdr.Close();
            cmd.Dispose();
            conn.Close();

        }
        private void dgvHangHoa_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            updateControl(e.RowIndex);
        }

        private void updateControl(int rowIndex)
        {
            if (rowIndex < 0)
            {
                rowIndex = 0;
            }
            else if (rowIndex >= dgvHangHoa.Rows.Count)
            {
                rowIndex = dgvHangHoa.Rows.Count - 1;
            }
            //cập nhật textbox
            txtMaHang.Text = dgvHangHoa.Rows[rowIndex].Cells[0].Value.ToString();
            txtTenHang.Text = dgvHangHoa.Rows[rowIndex].Cells[1].Value.ToString();
            txtDvt.Text = dgvHangHoa.Rows[rowIndex].Cells[2].Value.ToString();
            txtGia.Text = dgvHangHoa.Rows[rowIndex].Cells[3].Value.ToString();
            txtSlg.Text = dgvHangHoa.Rows[rowIndex].Cells[4].Value.ToString();

            //cập nhật combox loại hàng
            for (int i = 0; i < cbxLoai.Items.Count; i++)
            {
                if (cbxLoai.GetItemText(cbxLoai.Items[i]) == dgvHangHoa.Rows[rowIndex].Cells[5].Value.ToString())
                {
                    cbxLoai.SelectedIndex = i;
                }
            }
            // chọn hàng
            dgvHangHoa.Rows[rowIndex].Selected = true;

        }
        private void cbxLoai_SelectedIndexChanged(object sender, EventArgs e)
        {
            //MessageBox.Show((sender as ComboBox).SelectedItem.ToString());
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            int rowIndex = 0;
            dgvHangHoa.ClearSelection();
            updateControl(rowIndex);
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            
            int rowIndex = dgvHangHoa.SelectedRows[0].Index - 1;
            dgvHangHoa.ClearSelection();
            updateControl(rowIndex);
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            int rowIndex = dgvHangHoa.SelectedRows[0].Index + 1;
            dgvHangHoa.ClearSelection();
            updateControl(rowIndex);
        }

        private void btnEnd_Click(object sender, EventArgs e)
        {
            int rowIndex = dgvHangHoa.Rows.Count - 1;
            dgvHangHoa.ClearSelection();
            updateControl(rowIndex);
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            txtDvt.Clear();
            txtGia.Clear();
            txtMaHang.Clear();
            txtSlg.Clear();
            txtTenHang.Clear();
        }

        private void txtMaHang_TextChanged(object sender, EventArgs e)
        {
            if (ConnectionState.Closed == conn.State)
                conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            //load datagridview
            cmd.CommandText = "select MaHang from HangHoa where MaHang = '" + txtMaHang.Text + "'";
            SqlDataReader sdr = cmd.ExecuteReader();
            if (sdr.HasRows)
            {
                btnSave.Enabled = false;
                btnDelete.Enabled = true;
                btnUpdate.Enabled = true;
                btnDelete.Enabled = true;
            }
            else
            {
                btnSave.Enabled = true;
                btnDelete.Enabled = false;
                btnUpdate.Enabled = false;
                btnDelete.Enabled = false;
            }
            sdr.Close();
            conn.Close();
            cmd.Dispose();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ConnectionState.Closed == conn.State)
                conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            //load datagridview
            cmd.CommandText = String.Format("insert into HANGHOA values('{0}', N'{1}', N'{2}', {3}, '{4}', {5})", txtMaHang.Text, txtTenHang.Text, txtDvt.Text, txtGia.Text, cbxLoai.SelectedValue, txtSlg.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            conn.Close();
            updateDataGridView();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (ConnectionState.Closed == conn.State)
                conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            //load datagridview
            cmd.CommandText = String.Format("update HANGHOA set TenHang = N'{0}', DVTinh = '{1}', DonGia = {2}, MaLoai = '{3}', SoLuongMua = {4} where MaHang = '{5}'", txtTenHang.Text, txtDvt.Text, txtGia.Text, cbxLoai.SelectedValue, txtSlg.Text, txtMaHang.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            conn.Close();
            updateDataGridView();

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (ConnectionState.Closed == conn.State)
                conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            //load datagridview
            cmd.CommandText = "delete from HANGHOA where MaHang = '" + txtMaHang.Text + "'";
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            conn.Close();
            updateDataGridView();
        }
    }
}
