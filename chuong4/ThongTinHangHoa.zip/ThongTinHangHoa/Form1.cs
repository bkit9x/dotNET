﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ThongTinHangHoa
{
    public partial class Form1 : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=KIT\SQLEXPRESS;Initial Catalog=QLBH;Integrated Security=True");
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (ConnectionState.Closed == conn.State)
                conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            //load datagridview
            cmd.CommandText = "select h.MaHang, h.TenHang, h.DVTinh, h.DonGia, h.SoLuongMua, l.TenLoai from HANGHOA as h, LOAIHANG as l where h.MaLoai = l.MaLoai";
            SqlDataReader sdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(sdr);
            dgvHangHoa.DataSource = dt;
            dgvHangHoa.AutoResizeColumns();
            string[] VietSub = { "Mã hàng", "Tên hàng", "Đơn vị tính", "Giá", "Số lượng", "Tên loại" };
            for (int i = 0; i < VietSub.Length; i++)
            {
                dgvHangHoa.Columns[i].HeaderText = VietSub[i];
            }
            dt.Dispose();
            sdr.Close();

            //load cbxLoai
            SqlCommand com = new SqlCommand();
            com.Connection = conn;
            com.CommandText = "select MaLoai, TenLoai from LOAIHANG";
            com.Connection = conn;
            SqlDataReader sdr2 = com.ExecuteReader();

            DataTable dt2 = new DataTable();
            dt2.Load(sdr2);
            cbxLoai.DataSource = dt2;
            cbxLoai.DisplayMember = "TenLoai";
            cbxLoai.ValueMember = "MaLoai";

            sdr2.Close();

            conn.Close();

        }

        private void dgvHangHoa_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtMaHang.Text = dgvHangHoa.CurrentRow.Cells[0].Value.ToString();
            txtTenHang.Text = dgvHangHoa.CurrentRow.Cells[1].Value.ToString();
            txtDvt.Text = dgvHangHoa.CurrentRow.Cells[2].Value.ToString();
            txtGia.Text = dgvHangHoa.CurrentRow.Cells[3].Value.ToString();
            txtSlg.Text = dgvHangHoa.CurrentRow.Cells[4].Value.ToString();
            //cbxLoai.SelectedText = dgvHangHoa.CurrentRow.Cells[5].Value.ToString();
            //cbxLoai.SelectedItem = dgvHangHoa.CurrentRow.Cells[5].Value.ToString();
            cbxLoai.SelectedText = dgvHangHoa.CurrentRow.Cells[5].Value.ToString();

        }

    }
}
